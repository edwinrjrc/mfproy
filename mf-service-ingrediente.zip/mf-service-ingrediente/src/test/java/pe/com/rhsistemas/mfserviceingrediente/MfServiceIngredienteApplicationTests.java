package pe.com.rhsistemas.mfserviceingrediente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfServiceIngredienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
