package pe.com.rhsistemas.mfjpaingrediente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfJpaIngredienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
