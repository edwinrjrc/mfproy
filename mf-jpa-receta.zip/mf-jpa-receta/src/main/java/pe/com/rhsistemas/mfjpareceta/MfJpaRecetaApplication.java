package pe.com.rhsistemas.mfjpareceta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MfJpaRecetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MfJpaRecetaApplication.class, args);
	}

}
