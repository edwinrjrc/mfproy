package pe.com.rhsistemas.mfjpareceta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfJpaRecetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
